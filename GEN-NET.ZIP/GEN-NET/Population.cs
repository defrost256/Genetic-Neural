﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GEN_NET
{
	public class Population<T, U> where T : Individual<U>, new()
	{
		public List<Individual<U>> currentGeneration;
		List<Individual<U>> nextGeneration;
		int size;
		public CrossOverInfo info;
		public int Count
		{
			get { return size; }
		}
		Random rnd;

		public Population(int size, int seed, List<NodeType> points){
			try
			{
				this.size = size;
				rnd = new Random(seed);
				currentGeneration = new List<Individual<U>>();
				nextGeneration = new List<Individual<U>>();
				T currentIndividual;
				for (int i = 0; i < size; i++)
				{
					currentIndividual = new T();
					currentIndividual.createNetwork(points);
					currentIndividual.randomizeNetwork(rnd);
					currentGeneration.Add(currentIndividual);
				}
				#region initCrossoverInfo

				info = new CrossOverInfo(rnd, CrossoverType.SWAPPING);
				info.mutationChance = 0.3f;
				info.mutationStrength = 0.5f;

				#endregion
			}
			catch (Exception e)
			{
				throw new NullReferenceException("Message: " + e.Message + "\nStackTrace: " + e.StackTrace + "\nTargetSite: " + e.TargetSite + "\nSource: " + e.Source);
			}
		}

		public Population(int size, List<NodeType> points) : this(size, DateTime.Now.Millisecond, points)
		{
		}

		public void createNextGeneration(List<float> fitnessValues)
		{
			nextGeneration = new List<Individual<U>>();
			int parent1, parent2, i;
			for (i = 1; i < size; i++)
			{
				fitnessValues[i] += fitnessValues[i - 1];
			}
			
			for (i = 0; i < size; i++)
			{
				getParent(fitnessValues, out parent1);
				getParent(fitnessValues, out parent2);
				float sum = fitnessValues[parent1] + fitnessValues[parent2];
				info.crossOverRatio = fitnessValues[parent1] / sum;

				nextGeneration.Add(currentGeneration[parent1].crossOver(currentGeneration[parent2], info));
			}
			currentGeneration = nextGeneration;
		}

		void getParent(List<float> fitnessValues, out int parent)
		{
			int i;
			float tmp = fitnessValues[size - 1];
			tmp *= (float)rnd.NextDouble();
			for (i = 0; i < size; i++)
			{
				if (fitnessValues[i] > tmp)
					break;
			}
			parent = i;
		}

		public override string ToString()
		{
			String ret = "Population<" + typeof(T) + "," + typeof(U) + "> currentGeneration:";

			foreach (T individual in currentGeneration)
			{
				ret += " " + individual.ToString();
			}

			return ret;
		}
	}
}
