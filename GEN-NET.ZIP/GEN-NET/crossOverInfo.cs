﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GEN_NET
{

	public enum CrossoverType { SWAPPING, AVERAGING }

	public class CrossOverInfo
	{
		Random rnd;
		public float Rnd
		{
			get { return (float)rnd.NextDouble(); }
		}
		public float crossOverRatio;
		CrossoverType type;
		public CrossoverType Type
		{
			get { return type; }
		}
		public float mutationChance;
		public float mutationStrength;

		public CrossOverInfo(Random rnd, CrossoverType type){
			this.rnd = rnd;
			this.type = type;
		}
	}
}
